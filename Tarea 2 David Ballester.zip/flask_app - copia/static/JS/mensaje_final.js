let final = document.getElementById("final-btn");
if (final) {
    final.addEventListener("click", () => {
        window.location.href = "/";
    });
}