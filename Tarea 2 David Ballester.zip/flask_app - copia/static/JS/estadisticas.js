let final = document.getElementById("stats-btn");
if (final) {
    final.addEventListener("click", () => {
        window.location.href = "/";
    });
}